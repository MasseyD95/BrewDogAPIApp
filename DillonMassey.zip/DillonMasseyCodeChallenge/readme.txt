// Readme for Dillon Massey code challenge submission

The submission is the entire xcode project. I have only managed to test this via the simulator so it is recommended that this is ran through xcode for simulator only.

The app consists of three screens
- One for attempting to call the Brewdog web api, showing an alert if this fails, or there is no data stored on disk. If data is found then;
- A collection view is presented showing a list of beers with the documented summary information. When a cell is tapped
- A detailed view of that beer is shown.

Persistance 
The app persists the data by using NSFileCoordinator to write the data to a text file inside the users documents filespace. This was chosen as the data is not sensitive or private. This is also why the data is saved as plain text. There is some aspect of expandability here to show how this would work on a large scale, with having multiple storage type classes inheriting a base class, for the store/load logic, using protocols. 

If I had more time then this would be expanded to
- Save the data into specific area such as an App group
- To encrypt the data using one of the various encryptions, or potentially just base 64 encoding the data to give it some masking
- Add more utility functions to store/load so there is more flexibility.


User Interface
I initially opted to use collection views since you can have a lot of control over cell layout and structure. Without a specific brief of what the end output was I was struggling to figure out a way to make a grid view work with the data provided. There were some images you could download from the API but these seemed inconsistent.
I had some ideas of showing the view as cards where you could swipe left and right and they would revolve around the center, but with the time I decided to opt for a more simple look which demonstrates storyboard UI creation alongside setting up a class to work with the datasource and cells provided.

If I had more time then;
- I would probably had gone back to use a table view since I stuck to the 1 item per row model.
- Add specific tap/hold animations to the cells
- Make the detailed view a popover which took up a % of the screen dimming the background.

Unit testing
I only have minimal experience with unit testing so this is the one area of the project lacking. I have shown a couple examples of unit tests I would implement to test specific features. 

If I had more time I would have;
- Looked into adding more UI unit tests
- Expanded the unit tests to call more of the core GET data flow and supplying this to the collection views